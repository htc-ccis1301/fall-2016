---
title: "Use git to obtain, update, and version files on GitHub."
published: true
morea_id: out-github-basics
morea_type: outcome
morea_sort_order: 4
---

The student will be able to use git to:

- obtain a local copy of a repository and its files from GitHub
- stage modified files to be versioned and updated
- version the changes to the repository files
- update GitHub with the revised version of the repository files

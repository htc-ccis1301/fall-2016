---
title: "Practice Using the Shell"
published: true
morea_id: using-shell
morea_type: experience
morea_summary: "Practice using the shell to perform basic commands."
morea_sort_order: 3
---

# Practice using the shell

## Launching GitShell on Windows
If you are a Windows user, typically you will use PowerShell as your command shell.  However, when working with git commands, you'll want to make sure that you launch GitShell which you should now have installed as part of GitHub Desktop. (If you did not install this yet, go back and work through the steps outlined in [Getting Started]() ) GitShell is PowerShell plus git commands, and since we will mainly be using the shell for git commands, you will want to use GitShell for your work in this course.


## Using Terminal on Mac

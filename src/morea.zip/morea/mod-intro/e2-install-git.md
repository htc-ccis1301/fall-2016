---
title: "Install Git"
published: true
morea_id: install-git
morea_type: experience
morea_summary: "How to install git on Windows through GitHub Desktop, and check for and install git (if needed) on a Mac."
morea_sort_order: 2
---

# Install Git

## Windows Users




## Mac Users

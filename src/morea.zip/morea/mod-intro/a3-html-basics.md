---
title: "Foundational HTML Skills"
published: true
morea_id: asm-html-min
morea_type: assessment
morea_sort_order: 3
morea_outcomes_assessed:
  - out-html-min
---

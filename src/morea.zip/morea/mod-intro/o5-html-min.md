---
title: "Use a text editor to create, edit and save a minimal HTML file."
published: true
morea_id: out-html-min
morea_type: outcome
morea_sort_order: 5
---

The student will be able to use a text editor to:

- create a new HTML file
- identify and add the minimal required HTML elements
- open an existing HTML file
- edit and save changes to an HTML file
- preview the web page in a web browser

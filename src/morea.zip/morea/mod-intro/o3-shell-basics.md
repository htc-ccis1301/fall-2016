---
title: "Use the shell to navigate the file system"
published: true
morea_id: out-shell-basics
morea_type: outcome
morea_sort_order: 3
---

The student will be able to use the shell to:

- identify the current working directory
- view files in the current working directory
- change the current working directory

---
title: "Practice Using Git & GitHub"
published: true
morea_id: using-github
morea_type: experience
morea_summary: "Practice using the shell, git and GitHub to get, create, update and manage files."
morea_sort_order: 4
---

# Practice using Git and GitHub

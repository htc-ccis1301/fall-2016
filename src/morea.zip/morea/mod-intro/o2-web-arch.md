---
title: "Describe the client-server architecture of the internet and the request-response life-cycle."
published: true
morea_id: out-web-arch
morea_type: outcome
morea_sort_order: 2
---

Describe the client/server architecture of the internet and the request-response life-cycle.

- Describe a general client/server architecture.
- Explain how the internet is an example of a client/server architecture.
- Explain the process that takes place for a web browser to display a web page.

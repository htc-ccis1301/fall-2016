---
title: "HTML Basics"
published: true
morea_id: html-basics
morea_icon_url: /morea/html-basics/html-basics-logo.png
morea_summary: "An introduction to basic structural HTML tags."
morea_type: module
morea_sort_order: 2
morea_outcomes:
morea_readings:
  - html-review
  - html-basics-ch2
morea_experiences:
#  - validation-lab
---

{{page.morea_summary}}

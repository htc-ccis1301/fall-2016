---
title: "Basic HTML"
published: true
morea_id: html-basics-ch2
morea_summary: "An introduction to basic HTML tags for outlining content and creating links."
morea_type: reading
morea_sort_order: 1
---

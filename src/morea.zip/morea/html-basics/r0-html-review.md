---
title: "HTML Review"
published: true
morea_id: html-review
morea_summary: "A review of the foundational HTML tags and HTML document structure."
morea_type: reading
morea_sort_order: 0
---

---
title: "Ignored"
morea_id: morea_overview_readings
morea_type: overview_readings
published: true
---

This page collects together all of the "readings" associated with individual modules. 

In this site, readings represent "passive" learning opportunities, as opposed to experiences, which represent "active" learning opportunities.  In many courses, readings and experiences together constitute the "assignments". 
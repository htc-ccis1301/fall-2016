---
title: "Bootstrap Basics"
published: true
morea_id: prereq-bootstrap-basics
morea_type: prerequisite
---
You need to have a solid foundation with the Bootstrap Basics before beginning this topic.

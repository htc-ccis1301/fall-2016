---
title: "HTML Basics"
published: true
morea_id: prereq-resp-design
morea_type: prerequisite
---
You need to understand responsive web design before beginning this topic.

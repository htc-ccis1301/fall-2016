---
title: "Footer"
morea_id: footer
morea_type: footer
---

This course is developed for Hennepin Technical College by <mary.mosman@hennepintech.edu>

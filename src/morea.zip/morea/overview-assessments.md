---
title: "Ignored"
morea_id: morea_overview_assessments
morea_type: overview_assessments
published: true
---

This page collects together all of the "assessments" associated with individual modules.   

In this site, assessments represent the *results* of performing assessment activities, not the assessments themselves.  (Usually, you don't want to publish the actual assessment instruments (i.e. the tests) on the course website!)  

Publishing assessment results enable students to see how well they did compared to others.  It also allows the instructor to provide feedback about the assessment activity. 
---
title: "More Bootstrap"
published: true
morea_id: bootstrap-adv
morea_outcomes:
morea_readings:
morea_experiences:
morea_assessments:
morea_prerequisites:
 - prereq-bootstrap-basics
morea_type: module
morea_sort_order: 14
morea_labels:
 - Bootstrap
 - advanced
---

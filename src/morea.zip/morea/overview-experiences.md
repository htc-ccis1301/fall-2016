---
title: "Ignored"
morea_id: morea_overview_experiences
morea_type: overview_experiences
published: true
---

This page collects together all of the "experiences" associated with individual modules. 

In this site, experiences represent "active" learning opportunities, as opposed to readings, which represent "passive" learning opportunities.  In many courses, readings and experiences together constitute the "assignments". 
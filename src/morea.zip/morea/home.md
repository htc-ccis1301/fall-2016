---
title: "Home"
morea_id: home
morea_type: home
---

## Welcome to CCIS 1301

### Course Description
This course is an introduction to web development with HTML and CSS. In this course, students will learn about key internet technologies and standards behind the internet and world wide web. Students will develop website projects that meet current web standards and industry best practices using modern tools and techniques. The focus of this course is on the use of basic HTML and CSS as a technical foundation for later coursework in web application development using JavaScript and/or back-end technologies such as .Net or Java.

### Course Objectives
The following objectives will be addressed in the course:

- Identify key internet technologies, standards and organizations.
- Describe the client-server architecture of the internet and the request-response life-cycle.
- Build HTML pages that use best practices for layout, navigation, tables, forms, images and multimedia.
- Write CSS to layout, format and enhance the display of a web page applying industry best practices.
- Develop web pages that alter the visual layout and display appropriately for presentation on devices of various sizes.
- Use a source code management tool to maintain a website.
- Understand the impact of accessibility barriers in website design and development.
- Learn and apply a current industry web development framework or library to development of a website.

### Schedule
- Week 1 (8/22): Module 1 - Intro
- Week 2 (8/29): Module 2 - HTML Basics
- Week 3 (9/5):  Module 3 - CSS Basics
- Week 4 (9/12): Module 4 - Images & Text Styling
- Week 5 (9/19): Module 5 - Adv CSS
- Week 6 (9/26): Module 6 - Page Layout
- Week 7 (10/3): Module 7 - Web Design
- Week 8 (10/10): Module 8 - Responsive Design
- Week 9 (10/17): Module 9 - Tables
- Week 10 (10/24): Module 10 - Forms
- Week 11 (10/31): Module 11 - Media & Interactivity
- Week 12 (11/7):  Module 12 - Web Publishing
- Week 13 (11/14): Module 13 - Introduction to Bootstrap
- Week 14 (11/21): Thanksgiving Week, No class
- Week 15 (11/28): Module 14 - Project Wrap-up
- Week 16 (12/6):  Module 14 continued - Project Wrap-up
- Week 17 (12/13): Final Exam

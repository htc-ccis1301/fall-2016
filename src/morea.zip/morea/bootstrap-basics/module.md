---
title: "Introduction to Bootstrap"
published: true
morea_coming_soon: true
morea_id: bootstrap-basics
morea_outcomes:
morea_readings:
morea_experiences:
morea_assessments:
morea_prerequisites:
 - prereq-html-basics
 - prereq-css-basics
 - prereq-resp-design
morea_type: module
morea_sort_order: 14
morea_labels:
 - Bootstrap
 - advanced
---

This is the third module in this sample template.
